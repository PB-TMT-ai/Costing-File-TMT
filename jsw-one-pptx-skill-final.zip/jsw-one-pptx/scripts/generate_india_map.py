#!/usr/bin/env python3
"""
India Map Generator for JSW One Presentations
Two modes (auto-detected from config):
  - State-level: shade entire states
  - District-level: shade individual districts (594 districts)
Both support city pin markers with labels and regional zoom.

Usage:
  python generate_india_map.py --preset pb_distribution --output map.png
  python generate_india_map.py --config custom.json --output map.png

District-level config example:
{
  "title": "CM Locations",
  "subtitle": "District-Level View",
  "categories": [
    {
      "name": "CM district",
      "color": "#213366",
      "districts": [
        {"district": "Jaipur", "state": "Rajasthan"},
        {"district": "Raipur", "state": "Chhattisgarh"}
      ]
    },
    {
      "name": "Service zone",
      "color": "#8FA4CC",
      "districts": [
        {"district": "Ajmer", "state": "Rajasthan"}
      ]
    }
  ],
  "shade_parent_states": true,
  "parent_state_color": "#C5D3E8",
  "cities": [
    {"name": "Jaipur", "lon": 75.79, "lat": 26.92, "size": 8}
  ],
  "xlim": [68, 98],
  "ylim": [6, 38],
  "dpi": 200
}

State-level config: same but use "states" instead of "districts" in categories.

Requires: geopandas matplotlib (pip install geopandas matplotlib --break-system-packages)
"""
import json, sys, os, argparse
import urllib.request

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GEOJSON_STATES = os.path.join(SCRIPT_DIR, "india_states.geojson")
GEOJSON_DISTRICTS = os.path.join(SCRIPT_DIR, "india_districts.geojson")
GEOJSON_OUTLINE = os.path.join(SCRIPT_DIR, "india_outline.geojson")

URLS = {
    GEOJSON_STATES: "https://raw.githubusercontent.com/geohacker/india/master/state/india_state.geojson",
    GEOJSON_DISTRICTS: "https://raw.githubusercontent.com/geohacker/india/master/district/india_district.geojson",
    GEOJSON_OUTLINE: "https://raw.githubusercontent.com/datameet/maps/master/Country/india-composite.geojson",
}

DEFAULT_COLOR = "#E8E8E8"
JSW_BLUE = "#213366"


def ensure_geojson(paths):
    for path in paths:
        if not os.path.exists(path) and path in URLS:
            print(f"  Downloading {os.path.basename(path)}...")
            urllib.request.urlretrieve(URLS[path], path)


def detect_mode(config):
    for cat in config.get("categories", []):
        if cat.get("districts"):
            return "district"
    return "state"


def render_pins(ax, config):
    marker_color = config.get("city_marker_color", "#EA2127")
    for city in config.get("cities", []):
        ax.plot(city["lon"], city["lat"], "o",
                color=city.get("color", marker_color),
                markersize=city.get("size", 7),
                markeredgecolor="white", markeredgewidth=1.0, zorder=5)
        ax.annotate(city["name"], (city["lon"], city["lat"]),
                    xytext=(10, 5), textcoords="offset points",
                    fontsize=city.get("fontsize", 8), fontweight="bold",
                    color=JSW_BLUE, fontfamily="sans-serif",
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="white",
                              edgecolor="#CCCCCC", alpha=0.9),
                    zorder=6)


def render_chrome(ax, config, xlim, ylim):
    import matplotlib.patches as mpatches

    cx = (xlim[0] + xlim[1]) / 2
    title = config.get("title", "")
    subtitle = config.get("subtitle", "")
    if title:
        ax.text(cx, ylim[1] - 0.5, title, fontsize=15, fontweight="bold",
                color=JSW_BLUE, ha="center", fontfamily="sans-serif")
    if subtitle:
        ax.text(cx, ylim[1] - 1.5, subtitle, fontsize=10, color="#7F7F7F",
                ha="center", fontfamily="sans-serif")

    items = []
    for cat in config.get("categories", []):
        items.append(mpatches.Patch(facecolor=cat["color"], edgecolor="white", label=cat["name"]))
    if config.get("shade_parent_states", False):
        items.append(mpatches.Patch(
            facecolor=config.get("parent_state_color", "#C5D3E8"),
            edgecolor="white", label="Parent state"))
    items.append(mpatches.Patch(facecolor=DEFAULT_COLOR, edgecolor="#999999",
                                label=config.get("default_label", "Rest of India")))
    ax.legend(handles=items, loc="lower left", fontsize=8, frameon=True,
              facecolor="white", edgecolor="#CCCCCC", bbox_to_anchor=(0.02, 0.02))


# ═══════════════════════════════════════════════════════
# STATE-LEVEL MAP
# ═══════════════════════════════════════════════════════
def generate_state_map(config, output):
    import geopandas as gpd
    import matplotlib.pyplot as plt

    ensure_geojson([GEOJSON_STATES, GEOJSON_OUTLINE])
    states = gpd.read_file(GEOJSON_STATES)
    outline = gpd.read_file(GEOJSON_OUTLINE)

    color_map = {}
    for cat in config.get("categories", []):
        for s in cat.get("states", []):
            color_map[s] = cat["color"]
    states["color"] = states["NAME_1"].apply(lambda s: color_map.get(s, DEFAULT_COLOR))

    fig, ax = plt.subplots(1, 1, figsize=(9, 11), facecolor="white")
    xlim, ylim = config.get("xlim", [68, 98]), config.get("ylim", [6, 38])

    outline.plot(ax=ax, color=DEFAULT_COLOR, edgecolor="#999999", linewidth=0.8)
    states.plot(ax=ax, color=states["color"], edgecolor="white", linewidth=0.5)
    outline.boundary.plot(ax=ax, color="#999999", linewidth=0.8)

    ax.set_xlim(*xlim); ax.set_ylim(*ylim); ax.axis("off")
    render_pins(ax, config)
    render_chrome(ax, config, xlim, ylim)

    plt.tight_layout(pad=0.5)
    plt.savefig(output, dpi=config.get("dpi", 200), bbox_inches="tight", facecolor="white")
    plt.close()
    return output


# ═══════════════════════════════════════════════════════
# DISTRICT-LEVEL MAP
# ═══════════════════════════════════════════════════════
def generate_district_map(config, output):
    import geopandas as gpd
    import matplotlib.pyplot as plt

    ensure_geojson([GEOJSON_DISTRICTS, GEOJSON_OUTLINE])
    districts = gpd.read_file(GEOJSON_DISTRICTS)
    outline = gpd.read_file(GEOJSON_OUTLINE)

    # Build lookup
    dist_colors = {}
    parent_states = set()
    for cat in config.get("categories", []):
        for d in cat.get("districts", []):
            dist_colors[(d["district"], d["state"])] = cat["color"]
            parent_states.add(d["state"])
        for s in cat.get("states", []):
            parent_states.add(s)

    shade_parents = config.get("shade_parent_states", True)
    parent_color = config.get("parent_state_color", "#C5D3E8")

    # State-level colors if mixed mode
    state_colors = {}
    for cat in config.get("categories", []):
        for s in cat.get("states", []):
            state_colors[s] = cat.get("state_color", cat["color"])

    def get_color(row):
        key = (row["NAME_2"], row["NAME_1"])
        if key in dist_colors:
            return dist_colors[key]
        if row["NAME_1"] in state_colors:
            return state_colors[row["NAME_1"]]
        if shade_parents and row["NAME_1"] in parent_states:
            return parent_color
        return DEFAULT_COLOR

    districts["color"] = districts.apply(get_color, axis=1)

    fig, ax = plt.subplots(1, 1, figsize=(9, 11), facecolor="white")
    xlim, ylim = config.get("xlim", [68, 98]), config.get("ylim", [6, 38])

    outline.plot(ax=ax, color=DEFAULT_COLOR, edgecolor="#999999", linewidth=0.8)
    districts.plot(ax=ax, color=districts["color"], edgecolor="white", linewidth=0.15)
    states_dissolved = districts.dissolve(by="NAME_1")
    states_dissolved.boundary.plot(ax=ax, color="#999999", linewidth=0.6)
    outline.boundary.plot(ax=ax, color="#999999", linewidth=0.8)

    ax.set_xlim(*xlim); ax.set_ylim(*ylim); ax.axis("off")
    render_pins(ax, config)
    render_chrome(ax, config, xlim, ylim)

    # Match report
    for cat in config.get("categories", []):
        for d in cat.get("districts", []):
            match = districts[(districts["NAME_2"] == d["district"]) & (districts["NAME_1"] == d["state"])]
            tag = "MATCHED" if len(match) > 0 else "NOT FOUND"
            print(f"  [{tag}] {d['district']}, {d['state']}")

    plt.tight_layout(pad=0.5)
    plt.savefig(output, dpi=config.get("dpi", 200), bbox_inches="tight", facecolor="white")
    plt.close()
    return output


# ═══════════════════════════════════════════════════════
# MAIN ENTRY
# ═══════════════════════════════════════════════════════
def generate_map(config, output=None):
    out = output or config.get("output", "india_map.png")
    mode = detect_mode(config)
    print(f"Mode: {mode}-level | Output: {out}")
    if mode == "district":
        return generate_district_map(config, out)
    return generate_state_map(config, out)


PRESETS = {
    "pb_distribution": {
        "title": "JSW One TMT distribution footprint",
        "subtitle": "300+ districts across North and East India",
        "categories": [
            {"name": "Current distribution", "color": "#213366",
             "states": ["Uttar Pradesh","Bihar","Jharkhand","West Bengal","Odisha",
                        "Madhya Pradesh","Rajasthan","Delhi","Haryana","Punjab",
                        "Uttaranchal","Chhattisgarh","Assam"]},
            {"name": "Planned expansion", "color": "#8FA4CC",
             "states": ["Maharashtra","Gujarat","Andhra Pradesh","Telangana",
                        "Karnataka","Tamil Nadu","Kerala"]}
        ],
        "cities": [
            {"name": "Delhi", "lon": 77.2, "lat": 28.6},
            {"name": "Lucknow", "lon": 80.9, "lat": 26.8},
            {"name": "Patna", "lon": 85.1, "lat": 25.6},
            {"name": "Kolkata", "lon": 88.4, "lat": 22.6},
            {"name": "Bhubaneswar", "lon": 85.8, "lat": 20.3},
            {"name": "Bhopal", "lon": 77.4, "lat": 23.3},
            {"name": "Jaipur", "lon": 75.8, "lat": 26.9},
            {"name": "Guwahati", "lon": 91.7, "lat": 26.1},
            {"name": "Ranchi", "lon": 85.3, "lat": 23.3}
        ]
    },
    "homes_studios": {
        "title": "JSW One Homes studio locations",
        "subtitle": "Live and planned studios across India",
        "categories": [
            {"name": "Live studios", "color": "#213366",
             "states": ["Karnataka","Tamil Nadu","Telangana","Madhya Pradesh"]},
            {"name": "Planned studios", "color": "#8FA4CC",
             "states": ["Maharashtra","Odisha","Chhattisgarh"]}
        ],
        "cities": [
            {"name": "Bangalore", "lon": 77.6, "lat": 13.0, "size": 7},
            {"name": "Chennai", "lon": 80.3, "lat": 13.1, "size": 7},
            {"name": "Coimbatore", "lon": 76.9, "lat": 11.0, "size": 7},
            {"name": "Hyderabad", "lon": 78.5, "lat": 17.4, "size": 7},
            {"name": "Salem", "lon": 78.2, "lat": 11.7, "size": 5},
            {"name": "Indore", "lon": 75.9, "lat": 22.7, "size": 5},
            {"name": "Bellary", "lon": 76.4, "lat": 15.1, "size": 5},
            {"name": "Hubli", "lon": 75.1, "lat": 15.4, "size": 5},
            {"name": "Kochi", "lon": 76.3, "lat": 10.0, "size": 5}
        ]
    },
    "construction_presence": {
        "title": "Construction retail presence",
        "subtitle": "Retailer network across India",
        "categories": [
            {"name": "Active states", "color": "#213366",
             "states": ["Uttar Pradesh","Bihar","Jharkhand","West Bengal",
                        "Madhya Pradesh","Rajasthan","Maharashtra","Gujarat",
                        "Karnataka","Telangana","Odisha","Chhattisgarh"]}
        ],
        "cities": []
    }
}

# District names reference (for matching):
# GeoJSON uses NAME_2 for district, NAME_1 for state.
# State names: "Uttar Pradesh", "Rajasthan", "Chhattisgarh", "Himachal Pradesh",
#   "Punjab", "Haryana", "Bihar", "Jharkhand", "West Bengal", "Odisha" (not Orissa
#   in districts file — check with "Orissa"), "Madhya Pradesh", "Maharashtra",
#   "Gujarat", "Karnataka", "Tamil Nadu", "Andhra Pradesh" (includes Telangana
#   districts), "Kerala", "Uttaranchal", "Delhi", "Assam", etc.
# Run: python -c "import geopandas as gpd; d=gpd.read_file('india_districts.geojson'); print(sorted(d['NAME_1'].unique()))"
# to see all state names, or filter districts by state.

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="India map generator (state + district level)")
    parser.add_argument("--config", help="JSON config file")
    parser.add_argument("--preset", choices=list(PRESETS.keys()))
    parser.add_argument("--output", default="india_map.png")
    args = parser.parse_args()

    if args.config:
        config = json.load(open(args.config))
    elif args.preset:
        config = PRESETS[args.preset]
    else:
        print("Usage: python generate_india_map.py --preset <name> | --config <file.json> --output <out.png>")
        print(f"Presets: {', '.join(PRESETS.keys())}")
        sys.exit(1)

    print(f"Map saved: {generate_map(config, args.output)}")
